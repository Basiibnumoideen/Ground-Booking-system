from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(clubprofile)
admin.site.register(clubgallery)
admin.site.register(newstb)
admin.site.register(sportsitem)
admin.site.register(batch)
admin.site.register(batchtime)
admin.site.register(clubmember)
admin.site.register(batchregister)
admin.site.register(groundbooking)
admin.site.register(gender)
admin.site.register(purpose)
admin.site.register(Userprofile)
admin.site.register(Token)
admin.site.register(memberaccount)

